const displayMessage = function() {
    console.log('Hello there')
}

const updatedMessage = name => 'Hello there ' + name

console.log(updatedMessage('rapiddevpro'))